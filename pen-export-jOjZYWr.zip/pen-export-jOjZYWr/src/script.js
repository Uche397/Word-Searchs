const topics = {
    fruit: {
        easy: ['apple', 'pear', 'grape', 'lime', 'plum'],
        hard: ['pineapple', 'blueberry', 'strawberry', 'watermelon'],
        veryHard: ['pomegranate', 'blackberry', 'cantaloupe', 'dragonfruit']
    },
    aircraft: {
        easy: ['jet', 'prop', 'glider', 'drone'],
        hard: ['helicopter', 'balloon', 'biplane', 'zeppelin'],
        veryHard: ['aircraftcarrier', 'supersonic', 'airliner', 'spaceplane']
    },
    animals: {
        easy: ['cat', 'dog', 'fish', 'lion'],
        hard: ['elephant', 'giraffe', 'kangaroo', 'penguin'],
        veryHard: ['hippopotamus', 'rhinoceros', 'chimpanzee', 'orangutan']
    },
    countries: {
        easy: ['usa', 'canada', 'china', 'india'],
        hard: ['brazil', 'germany', 'australia', 'japan'],
        veryHard: ['southafrica', 'newzealand', 'switzerland', 'argentina']
    },
    colors: {
        easy: ['red', 'blue', 'green', 'yellow'],
        hard: ['purple', 'orange', 'cyan', 'magenta'],
        veryHard: ['turquoise', 'indigo', 'violet', 'maroon']
    },
    sports: {
        easy: ['soccer', 'tennis', 'golf', 'swim'],
        hard: ['volleyball', 'cricket', 'rugby', 'baseball'],
        veryHard: ['hockey', 'fencing', 'squash', 'kayaking']
    },
    vehicles: {
        easy: ['car', 'bike', 'bus', 'train'],
        hard: ['airplane', 'motorcycle', 'boat', 'submarine'],
        veryHard: ['helicopter', 'hotairballoon', 'spaceshuttle', 'tank']
    },
    nature: {
        easy: ['tree', 'rock', 'sky', 'lake'],
        hard: ['mountain', 'river', 'desert', 'forest'],
        veryHard: ['waterfall', 'volcano', 'canyon', 'rainforest']
    },
    food: {
        easy: ['bread', 'milk', 'cheese', 'cake'],
        hard: ['pasta', 'sushi', 'taco', 'curry'],
        veryHard: ['croissant', 'pho', 'baklava', 'paella']
    },
    professions: {
        easy: ['doctor', 'nurse', 'chef', 'farmer'],
        hard: ['engineer', 'pilot', 'artist', 'teacher'],
        veryHard: ['architect', 'scientist', 'surgeon', 'psychologist']
    },
    music: {
        easy: ['piano', 'guitar', 'drums', 'violin'],
        hard: ['trumpet', 'saxophone', 'cello', 'flute'],
        veryHard: ['trombone', 'oboe', 'bassoon', 'harpsichord']
    },
    movies: {
        easy: ['starwars', 'jaws', 'titanic', 'joker'],
        hard: ['inception', 'gladiator', 'interstellar', 'dunkirk'],
        veryHard: ['parasite', 'whiplash', 'midsommar', 'blade-runner']
    },
    literature: {
        easy: ['poem', 'novel', 'story', 'play'],
        hard: ['sonnet', 'essay', 'biography', 'drama'],
        veryHard: ['epic', 'fable', 'tragedy', 'narrative']
    },
    technology: {
        easy: ['phone', 'tablet', 'laptop', 'mouse'],
        hard: ['keyboard', 'monitor', 'router', 'server'],
        veryHard: ['microprocessor', 'algorithm', 'interface', 'cybersecurity']
    },
    history: {
        easy: ['king', 'queen', 'war', 'empire'],
        hard: ['revolution', 'dynasty', 'medieval', 'colonial'],
        veryHard: ['renaissance', 'feudalism', 'industrialization', 'enlightenment']
    },
    geography: {
        easy: ['river', 'mountain', 'ocean', 'desert'],
        hard: ['continent', 'peninsula', 'island', 'valley'],
        veryHard: ['plateau', 'canyon', 'fjord', 'archipelago']
    },
    space: {
        easy: ['star', 'moon', 'sun', 'planet'],
        hard: ['galaxy', 'nebula', 'asteroid', 'comet'],
        veryHard: ['quasar', 'pulsar', 'blackhole', 'supernova']
    },
    holidays: {
        easy: ['christmas', 'easter', 'halloween', 'birthday'],
        hard: ['thanksgiving', 'valentines', 'hanukkah', 'diwali'],
        veryHard: ['cinco de mayo', 'mardi gras', 'eid', 'oktoberfest']
    },
    ocean: {
        easy: ['fish', 'shark', 'whale', 'coral'],
        hard: ['dolphin', 'jellyfish', 'octopus', 'seahorse'],
        veryHard: ['anemone', 'squid', 'sea urchin', 'sea cucumber']
    },
    fashion: {
        easy: ['hat', 'shoe', 'dress', 'scarf'],
        hard: ['jacket', 'skirt', 'gloves', 'suit'],
        veryHard: ['tuxedo', 'trenchcoat', 'cardigan', 'pashmina']
    },
    architecture: {
        easy: ['house', 'bridge', 'tower', 'gate'],
        hard: ['cathedral', 'skyscraper', 'palace', 'mansion'],
        veryHard: ['basilica', 'aqueduct', 'monument', 'fortress']
    },
    mythology: {
        easy: ['zeus', 'thor', 'hera', 'odin'],
        hard: ['poseidon', 'hades', 'athena', 'apollo'],
        veryHard: ['hermes', 'ares', 'hestia', 'hephaestus']
    },
    health: {
        easy: ['heart', 'lungs', 'blood', 'bone'],
        hard: ['muscle', 'nerves', 'organs', 'immune'],
        veryHard: ['circulation', 'endocrine', 'respiratory', 'cardiovascular']
    },
    art: {
        easy: ['paint', 'brush', 'canvas', 'color'],
        hard: ['sculpture', 'gallery', 'portrait', 'landscape'],
        veryHard: ['fresco', 'mosaic', 'collage', 'printmaking']
    },
    education: {
        easy: ['school', 'teacher', 'student', 'classroom'],
        hard: ['curriculum', 'assignment', 'lecture', 'textbook'],
        veryHard: ['pedagogy', 'assessment', 'tutorial', 'seminar']
    }
};

const gridSize = {
    easy: 10,
    hard: 12,
    veryHard: 15
};

let timer;
let timeLeft = 90; // 1 minute 30 seconds
let selectedLevel = 'easy';
let selectedTopic = 'fruit';
let foundWords = [];
let selectedCells = [];
let grid = [];
let gamePaused = false;

document.getElementById('start-btn').addEventListener('click', startGame);
document.getElementById('pause-btn').addEventListener('click', pauseGame);
document.getElementById('resume-btn').addEventListener('click', resumeGame);
document.getElementById('quit-btn').addEventListener('click', quitGame);
document.getElementById('next-btn').addEventListener('click', nextTopic);

document.getElementById('difficulty').addEventListener('change', (e) => {
    selectedLevel = e.target.value;
});

document.getElementById('topic').addEventListener('change', (e) => {
    selectedTopic = e.target.value;
});

function startGame() {
    foundWords = [];
    selectedCells = [];
    gamePaused = false;

    resetTimer();
    enableButtons(true);
    createWordSearchGrid(topics[selectedTopic][selectedLevel], gridSize[selectedLevel]);
    displayWords(topics[selectedTopic][selectedLevel]);
    startTimer();
}

function createWordSearchGrid(wordsList, grid_size) {
    const gridContainer = document.getElementById('grid-container');
    gridContainer.innerHTML = '';
    gridContainer.style.gridTemplateColumns = `repeat(${grid_size}, 40px)`;
    
    grid = Array.from({ length: grid_size }, () => Array(grid_size).fill(' '));

    wordsList.forEach(word => {
        let placed = false;
        while (!placed) {
            const direction = Math.random() > 0.5 ? 'horizontal' : 'vertical';
            if (direction === 'horizontal') {
                const row = Math.floor(Math.random() * grid_size);
                const col = Math.floor(Math.random() * (grid_size - word.length));
                if (canPlaceWord(grid, word, row, col, 'horizontal')) {
                    for (let i = 0; i < word.length; i++) {
                        grid[row][col + i] = word[i].toUpperCase();
                    }
                    placed = true;
                }
            } else {
                const row = Math.floor(Math.random() * (grid_size - word.length));
                const col = Math.floor(Math.random() * grid_size);
                if (canPlaceWord(grid, word, row, col, 'vertical')) {
                    for (let i = 0; i < word.length; i++) {
                        grid[row + i][col] = word[i].toUpperCase();
                    }
                    placed = true;
                }
            }
        }
    });

    fillEmptySpaces(grid, grid_size);
    renderGrid(grid);
}

function canPlaceWord(grid, word, row, col, direction) {
    if (direction === 'horizontal') {
        for (let i = 0; i < word.length; i++) {
            if (grid[row][col + i] !== ' ') return false;
        }
    } else {
        for (let i = 0; i < word.length; i++) {
            if (grid[row + i][col] !== ' ') return false;
        }
    }
    return true;
}

function fillEmptySpaces(grid, grid_size) {
    for (let row = 0; row < grid_size; row++) {
        for (let col = 0; col < grid_size; col++) {
            if (grid[row][col] === ' ') {
                grid[row][col] = String.fromCharCode(65 + Math.floor(Math.random() * 26));
            }
        }
    }
}

function renderGrid(grid) {
    const gridContainer = document.getElementById('grid-container');
    grid.forEach((row, rowIndex) => {
        row.forEach((letter, colIndex) => {
            const cell = document.createElement('div');
            cell.classList.add('grid-cell');
            cell.textContent = letter;
            cell.addEventListener('click', () => handleCellClick(rowIndex, colIndex, cell));
            gridContainer.appendChild(cell);
        });
    });
}

function handleCellClick(row, col, cell) {
    if (selectedCells.some(cell => cell.row === row && cell.col === col)) {
        return;
    }
    
    cell.classList.add('selected');
    selectedCells.push({ row, col, element: cell });

    const selectedWord = selectedCells.map(cell => grid[cell.row][cell.col]).join('').toLowerCase();

    if (topics[selectedTopic][selectedLevel].includes(selectedWord)) {
        foundWords.push(selectedWord);
        markWordAsFound(selectedWord);
        selectedCells.forEach(cell => cell.element.classList.add('found'));
        selectedCells = [];
        
        if (foundWords.length === topics[selectedTopic][selectedLevel].length) {
            clearInterval(timer);
            document.getElementById('next-btn').disabled = false;
            alert(`Congratulations! You've completed the ${selectedTopic} topic!`);
        }
    } else if (selectedCells.length > 1 && !topics[selectedTopic][selectedLevel].some(word => word.startsWith(selectedWord))) {
        selectedCells.forEach(cell => cell.element.classList.remove('selected'));
        selectedCells = [];
    }
}

function markWordAsFound(word) {
    const wordListItems = document.querySelectorAll('#word-list li');
    wordListItems.forEach(item => {
        if (item.textContent.toLowerCase() === word) {
            item.classList.add('found');
        }
    });
}

function displayWords(wordsList) {
    const wordList = document.getElementById('word-list');
    wordList.innerHTML = '';
    wordsList.forEach(word => {
        const li = document.createElement('li');
        li.textContent = word.toUpperCase();
        wordList.appendChild(li);
    });
}

function startTimer() {
    clearInterval(timer);
    timeLeft = 90;
    updateTimerDisplay();
    timer = setInterval(() => {
        if (!gamePaused) {
            timeLeft--;
            updateTimerDisplay();
            if (timeLeft <= 0) {
                clearInterval(timer);
                alert("Time's up! Game over.");
                enableButtons(false);
            }
        }
    }, 1000);
}

function updateTimerDisplay() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    document.getElementById('timer').textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
}

function resetTimer() {
    clearInterval(timer);
    document.getElementById('timer').textContent = '1:30';
}

function pauseGame() {
    gamePaused = true;
    document.getElementById('pause-btn').disabled = true;
    document.getElementById('resume-btn').disabled = false;
}

function resumeGame() {
    gamePaused = false;
    document.getElementById('pause-btn').disabled = false;
    document.getElementById('resume-btn').disabled = true;
}

function quitGame() {
    clearInterval(timer);
    enableButtons(false);
    document.getElementById('grid-container').innerHTML = '';
    document.getElementById('word-list').innerHTML = '';
}

function nextTopic() {
    document.getElementById('next-btn').disabled = true;
    startGame();
}

function enableButtons(isPlaying) {
    document.getElementById('pause-btn').disabled = !isPlaying;
    document.getElementById('resume-btn').disabled = !isPlaying;
    document.getElementById('quit-btn').disabled = !isPlaying;
}
